#pragma once

#include "mavlink/common/mavlink.h"
