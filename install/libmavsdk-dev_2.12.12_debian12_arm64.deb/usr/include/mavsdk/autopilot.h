#pragma once

namespace mavsdk {

enum class Autopilot {
    Unknown,
    Px4,
    ArduPilot,
};

} // namespace mavsdk
